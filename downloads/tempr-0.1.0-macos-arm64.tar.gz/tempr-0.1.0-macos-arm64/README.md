# tempr 0.1.0 (macos-arm64)

An embedded C11 engine for live incremental analytics over events that can be corrected or deleted.

## Contents

- `bin/tempr`: Standalone CLI program & REPL
- `include/tempr.h`: Public C11 API
- `lib/libtempr.a`: Static library
- `lib/`: Shared library and pkg-config file
- `LICENSE`: Non-commercial binary distribution license

## Getting Started

Run the interactive REPL:
    ./bin/tempr

Run a script:
    ./bin/tempr your-script.tr

Link against the static library in C:
    cc -std=c11 -O2 -Iinclude app.c lib/libtempr.a -lm -o app

Online documentation and guides:
    https://github.com/mkeenan-kdb/tempr-private
