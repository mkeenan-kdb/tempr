# tempr 0.2.0 (macos-arm64)

An embedded C11 engine for live incremental analytics over events that can be corrected or deleted.

## Contents

- `bin/tempr`: Standalone CLI program & REPL
- `include/tempr.h`: Public C11 API
- `lib/libtempr.a`: Static library
- `lib/`: Shared library and pkg-config file
- `examples/wikipedia/`, `examples/quakes/`: live demos on public feeds, each on a local web page

## Getting Started

Run the interactive REPL:
    ./bin/tempr

Run a script:
    ./bin/tempr your-script.tr

Watch live Wikipedia edits, and past minutes revised as reverts arrive
(Python 3.8+, then open http://127.0.0.1:8000):
    python3 examples/wikipedia/wikipedia.py

Link against the static library in C:
    cc -std=c11 -O2 -Iinclude app.c lib/libtempr.a -lm -o app

Online documentation and guides:
    https://mkeenan-kdb.github.io/tempr/
